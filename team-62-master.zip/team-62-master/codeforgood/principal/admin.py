from django.contrib import admin
from .models import Principal

# Register your models here.
admin.site.register(Principal)
